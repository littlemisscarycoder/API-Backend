const db = require('../../database.js'); 

const produtoModel = {
    findAll: () => {
        return new Promise((resolve, reject) => {
            db.all("SELECT * FROM produtos", [], (err, rows) => {
                if (err) {
                    reject(err);
                }
                resolve(rows);
            });
        });
    },

    findById: (id) => {
        return new Promise((resolve, reject) => {
            db.all("SELECT * FROM produtos WHERE id =?", [id], (err, rows) => {
                if (err) {
                    reject(err);
                }
                resolve(row);
            });
        });
    },
}

//criar produto 
create: (nome, preco) => {
    return new Promise((resolve, reject) => {
        db.run("INSERT INTO produtos (nome, preco) VALUES (?, ?)"), [nome, preco], function(err) {
            if (err) {
                reject(err);
            }
            resolve({ id: this.lastId, nome, preco });
        }
    } 
)};

update: (id, nome, preco) => {
    return new Promise((resolve, reject) => {
        db.run(`UPDATE produtos SET nome = ?, preco = ?, WHERE id = ?`, [nome, preco, id], function (err) {
            if (err){
                reject(err);
            }
            resolve({ changes: this.changes });
        });
    });
}

erase: (id) => {
    return new Promise((resolve, reject) => {
        db.run("DELETE FROM produtos WHERE id = ?", 
               [id], function (err) {
            if (err) {
                reject(err);
            }
            resolve({ changes: this.changes });
        });
    });
}

module.exports = produtoModel;