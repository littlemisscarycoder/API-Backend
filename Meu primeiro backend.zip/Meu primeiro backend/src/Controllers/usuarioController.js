const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const JWT_SECRET = 'senha-forte';

const usuarios = [];

exports.criarUsuario = (req, res) => {
    const { nome, email, senha } = req.body;

    if (usuarios.find(u => u.email === email)) {
        return res.status(400).json({message: 'Email já cadastrado.'});        
    }

    // criptografa a senha antes de salvar
    const senhaCriptografada = bcrypt.hashSync(senha, 10);

    const novoUsuario = {
        id: usuarios.length + 1,
        nome,
        email,
        senha: senhaCriptografada
    };

    usuarios.push(novoUsuario);

    const {senha: _, ...usuarioSemSenha } = novoUsuario;
    res.status(201).json(usuarioSemSenha);
};

exports.login = (req, res) => {
    const { email, senha } = req.body;

    // encontrar user pelo email
    const usuario = usuarios.find(u => u.email === email);
  if (!usuario) {
    return res.status(401).json({ message: "Credenciais inválidas." }); // 401 Unauthorized
  };

   // comparar senha enviada c senha criptografada
   const senhaValida = bcrypt.compareSync(senha, usuario.senha);
  if (!senhaValida) {
    return res.status(401).json({ message: "Credenciais inválidas." });
  };

  //se estiver tudo certo, gera token JWT
  const token = jwt.sign(
    { id: usuario.id, nome: usuario.nome }, // Payload: dados que queremos guardar no token
    JWT_SECRET, // Nosso segredo
    { expiresIn: '1h' } // Opções, como o tempo de expiração
  );

  // enviar o token para o cliente
  res.status(200).json({
    message: "Login bem-sucedido!",
    token: token
  });
};
