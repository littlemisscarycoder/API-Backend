/*const express = require('express');
const app = express();
const PORTA = 3000;

app.use(express.json());

// importa o nosso arquivo de rotas de produtos
const produtoRoutes = require('./routes/produtoRoutes');
const usuarioRoutes = require('./routes/usuarioRoutes');

// Usamos o roteador na nossa aplicação, definindo um prefixo
// Todas as rotas em 'produtoRoutes' terão '/api/produtos' antes
app.use('/api/produtos', produtoRoutes);
app.use('/api/usuarios', usuarioRoutes);

// Rota de teste
app.get('/', (req, res) => {
  res.send('API de Produtos funcionando!');
});

// Inicialização do servidor
app.listen(PORTA, () => {
  console.log(`Servidor rodando em http://localhost:${PORTA}`);
  console.log(`rato do campo`)
});
*/

const sequelize = require('./database'); // Importa a conexão
const Produto = require('./models/produto'); // Importa o modelo

async function syncDatabase() {
    try {
        // .sync() verifica o estado dos modelos e os cria/altera no BD se necessário
        await sequelize.sync();
        console.log('Modelos sincronizados com o banco de dados.');
    } catch (error) {
        console.error('Erro ao sincronizar modelos:', error);
    }
}
syncDatabase();